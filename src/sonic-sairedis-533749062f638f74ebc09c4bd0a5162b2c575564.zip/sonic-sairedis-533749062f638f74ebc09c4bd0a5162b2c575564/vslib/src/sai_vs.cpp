#include "sai_vs.h"
#include "sai_vs_internal.h"

sai_status_t sai_dbg_generate_dump(
        _In_ const char *dump_file_name) 
{
    SWSS_LOG_ENTER();

    return SAI_STATUS_SUCCESS;
}
