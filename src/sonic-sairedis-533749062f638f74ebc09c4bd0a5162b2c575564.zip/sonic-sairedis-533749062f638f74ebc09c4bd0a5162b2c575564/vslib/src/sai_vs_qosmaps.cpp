#include "sai_vs.h"
#include "sai_vs_internal.h"

VS_GENERIC_QUAD(QOS_MAP,qos_map);

const sai_qos_map_api_t vs_qos_map_api = {

    VS_GENERIC_QUAD_API(qos_map)
};
